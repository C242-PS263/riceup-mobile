package com.riceup.riceapp.models

data class Category(
    val id: Int,
    val name: String
)